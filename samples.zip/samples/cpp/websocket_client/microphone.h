/**
 * Copyright FunASR (https://github.com/alibaba-damo-academy/FunASR). All Rights
 * Reserved. MIT License  (https://opensource.org/licenses/MIT)
 */

#ifndef WEBSOCKET_MICROPHONE_H_
#define WEBSOCKET_MICROPHONE_H_
#include <iostream>

class Microphone {
 public:
  Microphone();
  ~Microphone();
};

#endif  // WEBSOCKET_MICROPHONE_H_
